<template>
    <div>
        <h2>分类</h2>
    </div>
</template>

<script>
    export default {
        name: 'Classify'
    }
</script>

<style scoped>

</style>