<template>
    <div>
        <h2>关于</h2>
    </div>
</template>

<script>
    export default {
        name: 'About'
    }
</script>

<style scoped>

</style>